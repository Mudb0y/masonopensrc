Welcome to EasyPad
EasyPad is the self voicing notepad.

1. features
opening of files (in beta)
saving of files
choosing of filetypes

2. How to use
Launch pad.exe, and you are automatically in the textbox! Tab to open a file, save file, and quit buttons.
press f2 for a new line, sorry, this is a bit buggy too.

3. Opening a file
Click on the open file button. you are prompted for a filename. type in this filename and tab to the Open button. Hit enter or space.
If the file exists, you will be placed in the textbox with it's contents.
If not, it will be created and opened.

4. saving files.
Click the save file button.
Then, it asks you for a base filename. type in the title without the extention. then hit tab.
you are in a select filetype listbox. it has the currently added file extentions in it, see the section adding file types for more.
then click save.
If the file exists, you are prompted to either overwrite it or append to it.
Then it is saved!

5. adding file types
to add file types, go to filetypes.dat. You will see a list of file types supported, with a plus in between each one. to add another, just type the file extention, and then a plus. Like, say you wanted to add xml. You'd do this.
txt+bgt+au3+pb+dfe+xml

enjoy!
Mason