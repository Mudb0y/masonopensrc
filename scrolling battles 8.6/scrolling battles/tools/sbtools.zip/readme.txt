This is a set of tools allowing you to modify your scrolling battles 1 stats. tools.exe and tools1.exe can be launched separately, but you can't have scrolling battles running in order to do stuff to them.
When you go to tools or tools 1, it asks you if you want to view or edit an item. You can enter which ever you want. After this, you can enter in one of the following items: In tools.exe, you have the following:
blasterspeed
dollars
gametime
grenademove
grenaderange
grenades
grenadespeed
gunammo
gundamage
gunrange
helperdamage
helperhealth
helperrange
helperspeed
jumptime
kills
knifedamage
kniferange
laserdamage
lasergot
laserrange
macgunammo
macgundamage
macgunrange
macguntime
mastervolume
maxpos
musicvolume
playerhealth
pusherdamage
pusherrange
speedtime
telerange
telespeed

for tools1
attackspeed
batteries
defaultenemyhealth
enemylevel
enemyspeed
playerchancenumber
soundpack
sz1healthspeed
sz1length
sz1maxhealth
sz2healthspeed
sz2length
sz2maxhealth

Note: after this it will if you hit read tell you what the thing is set to, or edit ask you for a value. Enter that, and hit enter. Then, it will just set itself and close.
Enjoy!